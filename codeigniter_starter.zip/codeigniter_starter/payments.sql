-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 17, 2018 at 02:15 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shops`
--

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `pay_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `mounth` varchar(33) NOT NULL,
  `value` int(11) NOT NULL,
  `date` varchar(40) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`pay_id`, `user_id`, `mounth`, `value`, `date`, `note`) VALUES
(1, 1, 'septemper', 60, '0', ''),
(2, 1, 'septemper2', 60, '12', ''),
(4, 1, 'septemper', 60, '12', ''),
(5, 1, 'septemper', 60, '12', '0'),
(6, 1, 'septemper', 60, '12', 'sadasdasdasd'),
(7, 1, 'septemper', 60, '12-5-2018  6:24 PM', 'sadasdasdasd'),
(8, 1, 'septemper', 60, '12-5-2018  6:26 PM', ''),
(9, 1, 'septemper', 60, '12-5-2018  6:26 PM', ''),
(10, 1, 'septemper', 60, '12-5-2018  6:28 PM', ''),
(11, 1, 'septemper', 60, '12-5-2018  6:28 PM', ''),
(12, 1, 'septemper', 60, '12-5-2018  6:28 PM', ''),
(13, 1, 'septemper', 60, '12-5-2018  6:28 PM', 'asdasd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`pay_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `pay_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
