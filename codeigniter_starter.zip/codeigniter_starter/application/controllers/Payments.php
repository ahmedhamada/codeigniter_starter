<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payments extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		// debug
		$this->output->enable_profiler(TRUE);
	}

	// List all payments
	public function index()
	{
		echo json_encode($this->crud_model->get('payments') );
	}

	// Add a new item
	public function add()
	{
		$user_id = $this->input->post('user_id');
		$mounth = $this->input->post('mounth');
		$value = $this->input->post('value');
		// echo $note = ($this->input->post('note', true)!=='') ? $this->input->post('note') : ''; /*wrong way*/
		$note =(empty($this->input->post('note'))) ? '' : $this->input->post('note'); /*right way*/


		$data = array( 'user_id' => $user_id,
						'mounth' => $mounth,
						'value' => $value,
						'note' => $note,
						'date' => date('j-n-Y  g:i A')
		 );

		//rules
        $this->form_validation->set_rules('user_id', 'user id'     , 'required|greater_than[0]');
        $this->form_validation->set_rules('mounth', 'mounth'     , 'required|xss_clean');
        $this->form_validation->set_rules('value', 'value'     , 'required|greater_than[0]');
        $this->form_validation->set_rules('note', 'note'     , 'xss_clean');


		// validation
		if ($this->form_validation->run() == false){
			$errors =  validation_errors(' ',' ');
			echo json_encode(array("success"=>false,"message"=>$errors));
		}else{
			$add = $this->crud_model->add('payments' , $data);
			if ($add) {
				echo json_encode(array("success"=>true , "message"=>"added successfully"));
			}else{
				echo json_encode(array("success"=>false , "message"=>$this->db->error() ));
			}
		}

	}

	//Update one item
	public function update( $id = 0 )
	{
		if (empty($id)) {
       		echo json_encode(array("success"=>false , "message"=>"missing id @ url"));
			exit();
		}

		$data = array();
		if ($_POST['user_id']) {
			 $data['user_id'] = $this->input->post('user_id');
		}
		if ($_POST['mounth']) {
			 $data['mounth'] = $this->input->post('mounth');
		}
		if ($_POST['value']) {
			 $data['value'] = $this->input->post('value');
		}
		if ($_POST['note']) {
			 $data['note'] = $this->input->post('note');
		}

		//rules
        $this->form_validation->set_rules('user_id', 'user id'     , 'greater_than[0]');
        $this->form_validation->set_rules('mounth', 'mounth'     , 'xss_clean');
        $this->form_validation->set_rules('value', 'value'     , 'greater_than[0]');
        $this->form_validation->set_rules('note', 'note'     , 'xss_clean');


        if ($this->form_validation->run() == false) {
        	$errors =  validation_errors(' ',' ');
			echo json_encode(array("success"=>false,"message"=>$errors));
        }else{
        	$where = array('pay_id' => $id);
        	if ($this->crud_model->update('payments',$where , $data)) {
        		echo json_encode(array("success"=>true , "message"=>"updated successfully"));
        	}else{
        		echo json_encode(array("success"=>false , "message"=>"no thing changed"));
        	}
        }

	}

	//Delete one item
	public function delete( $id = 0 )
	{
		if ($this->crud_model->delete('payments',array('pay_id'=>$id))) {
        		echo json_encode(array("success"=>true , "message"=>"deleted successfully"));
		}else{
        	echo json_encode(array("success"=>false , "message"=>"no thing changed"));
		}
	}
}

/* End of file payments.php */
/* Location: ./application/controllers/payments.php */
