<?php 
defined('BASEPATH') OR exit('No direct script access allowed');


class Crud_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();

	}

	// List all your items
	public function index()
	{
		
	}

	// Add a new item
	public function add( $table , $data )
	{
		return $this->db->insert($table, $data);
	}






	// ====== get ======/
	public function get($table)
	{
		$q= $this->db->get($table);
		return $q->result_array($q);
	}
	// limit[item per page] ==> max number of return result  - default = 100000
	// offset[ page ] => start from row num any in return query
	// pagination ==> SELECT * FROM `products` limit 10 OFFSET 9
	// pagination ==> SELECT * FROM `products` limit 10 OFFSET 19
	// pagination ==> SELECT * FROM `products` limit 10 OFFSET 29
	public function get_where($table , $where ,  $limit = null ,$offset = null , $join = null , $join_on = null ,$left_or_right = 'left')
	{
		if ($limit == null) {$limit = 100000;}
		$this->db->limit($limit , $offset);
		if ($where != null) {$this->db->where($where);}
		if ($join != null) {$this->db->join($join, $join_on , $left_or_right);}
		// $this->db->join('categories', 'products.product_id = categories.categ_id','left');
		$query= $this->db->get($table);
		// $query = $this->db->get_where($table, $where, $limit , $offset);
		return $query->result_array($query);
	}

	public function count($table,$where = null)
	{
		if ($where != null) {
			$query = $this->db->get_where($table, $where);
		}else{
			$query = $this->db->get_where($table);
		}
		
		return $count = $query->num_rows();
	}

	// count where
	/*	
		public function count_where($table , $data){
			$this->db->where($data);
			return $this->db->count_all($table , $data);
		}
	*/

	// pagination
	//how many pagination available button 1 , 2 , 3 , ......
	public function pagination_counter($table , $items_per_page = 5)
	{
		$number_of_rows = $this->count($table);
		if (is_integer($items_per_page)  and $number_of_rows > 0) {
			$res =  ($number_of_rows / $items_per_page);
			return ceil( $res );
		}
	}
	public function get_columns($table)
	{
		return $fields = (array) $this->db->field_data($table);
	}



	public function search()
	{
		# code...
	}






	//======== Update one item ========//
	public function update( $table , $where = null , $data )
	{
		if ($where != null) {$this->db->where($where);}
		
		    $update = $this->db->update($table, $data);
			return  $this->db->affected_rows();  //return affected row -->when no change return 0
	}

	//Delete
	public function delete($table, $where ){
		$this->db->where($where);
		$this->db->delete($table);
		return $this->db->affected_rows();
	}

	public function inclement( $table , $where , $column , $inclement_by = 1)
	{
		     $this->db->set($column , "$column + $inclement_by" , false);
		     // $this->db->set($column , 'visits + 1' , false);
           $this->db->where($where);
          $status = $this->db->update($table);
	}








}

/* End of file Crud_model.php */
/* Location: ./application/models/Crud_model.php */
